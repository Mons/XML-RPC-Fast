#!/usr/bin/env bash

TEST_AUTHOR=1 runprove t/*.t
